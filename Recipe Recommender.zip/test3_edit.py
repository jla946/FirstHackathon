import json


f = open('recipes_raw_nosource_epi.json')
data = json.load(f)
ingredientList = [] # ingredients list
print("Hi! This program is to recommend recipes to people who has limited ingredients in their firdge.")
while True :
    eachIngredient = input("Tell me the ingredients you have, one at a time (enter 1 if you entered all of the ingredients): ")
    if eachIngredient == "1" :
        break
    ingredientList.append(eachIngredient)


foodlst = [] #this is going to be the list of food that contains the ingredients



#we have to get the ingredients , search for all of them
# append to the list for the first time
# then we delete from the lsit what we dont have
# then by length if there was more we we add a loop and search in the new list


for i in data :
   
   
    y = data[i]
    ingredient = y["ingredients"]
    itemInfood = set()
    for m in  ingredient :
        for item in ingredientList :
            inFood = m.find(item)
            if inFood != -1:
                itemInfood.add(item)
        if len(itemInfood) == len(ingredientList) :
            foodlst.append(i)
            break

if len(foodlst)<10 :
        print("Sorry we could not find enough recipes for you")
else:
    counter = 0
    foodsuggList = []
    print ("FOOD SUGGESTION LIST:\n")
    for i in foodlst: 
        counter += 1
        id = data[i] 
        foodsuggList.append(i)
        print (counter,"- ",id["title"],"\n")
   
        if counter == 10 :
            break
    
    inpt = int(input("Which one would you like to cook? (enter the number only): "))
    while True :
        if inpt > 10 or inpt < 1 :
            print ("Invalid input\n")
            inpt = int(input("Which one would you like to cook? (enter the number only): \n"))
        else:
            break
    userchoice = foodsuggList[inpt-1]
    id = data[userchoice]
    print ("\n**** \n",id["title"], "\n")
    print ("INGREDIENTS: ",id["ingredients"], "\n")
    print ("INSTRUCTIONS: ",id["instructions"], "\n")
    print ("************" , "\n")